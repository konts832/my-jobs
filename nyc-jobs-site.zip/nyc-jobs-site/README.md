# NYC Jobs Site

A simple GitHub Pages-hosted site to browse and search NYC government job listings.

Data Source: [NYC Open Data Jobs API](https://data.cityofnewyork.us/resource/kpav-sd4t.json)

## Features
- Fetch and display live job postings
- Search by title or agency
- Sort by posting date or job title

## Hosting
This project can be hosted for free using GitHub Pages.
